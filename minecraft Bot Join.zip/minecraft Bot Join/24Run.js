const mineflayer = require('mineflayer');

const bot = mineflayer.createBot({
  host: 'Frozxc98.aternos.me', // 例: example.com
  port: 35661,
  username: '1234567890A',
  version: '1.21.11'
});

// ログ
bot.on('login', () => {
  console.log('✅ ログイン成功');
});

// チャット受信
bot.on('chat', (username, message) => {
  console.log(`💬 ${username}: ${message}`);
});

// ランダムメッセージ
const messages = ['1', 'e', '2', '3'];

// 1分ごと送信
function sendLoop() {
  const delay = 60 * 1000; // 1分

  setTimeout(() => {
    const msg = messages[Math.floor(Math.random() * messages.length)];

    bot.chat(msg);
    console.log('📤 送信:', msg);

    sendLoop(); // ループ
  }, delay);
}

// スポーン後に開始
bot.once('spawn', () => {
  console.log('🌍 スポーン完了');
  sendLoop();
});

// エラー対策
bot.on('end', () => {
  console.log('❌ 切断 → 再接続...');
  setTimeout(() => process.exit(), 5000);
});

bot.on('error', err => {
  console.log('⚠️ エラー:', err.message);
});
